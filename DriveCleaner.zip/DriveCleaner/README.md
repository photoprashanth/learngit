# Drive Cleaner for Windows

Install Python 3.10 or newer from https://www.python.org/downloads/windows/ with Tcl/Tk and the Python launcher enabled. Extract this folder, then double-click **Run Cleaner.bat**. First launch requires Internet access to install Pillow and Send2Trash into a local virtual environment.

1. Choose an external drive or folder and click **Scan**. The Windows system drive is blocked. Scanning changes nothing.
2. In **Software review**, select unwanted files, or select all, then **Recycle selected software** and confirm.
3. In **Image review**, use **Keep / Next** to browse. **Recycle this image** immediately recycles the displayed image and advances. Restore mistakes from Windows Recycle Bin.

Software candidates: exe, jar, msi, msp, msix, msixbundle, appx, appxbundle, dll, sys, ocx, scr, com. Classification is based on extension, not content. These files may still be valuable; review the list before removing them. Software stored in other formats is retained.

Documents (including Word and Excel), audio, video, text, PDFs, databases, archives, scripts, disk images, extensionless files and all unrecognized formats are preserved. This app does not inspect content for passwords or keys; information inside software files could still be lost if those files are selected. Back up irreplaceable files first.

Image previews support JPEG, PNG, GIF (first frame), BMP, WebP, TIFF and ICO. Other image formats are kept but not shown. Empty directories are left alone. Permission errors are reported; links, junctions and protected Windows metadata directories are skipped. Stop scan also stops a recycling batch after its current file operation. Very large collections may use substantial memory.

Deletion uses Send2Trash, with no permanent-delete fallback. External drives, network volumes or Windows policies may prevent recycling; failed files remain in place. Avoid moving files or changing links on the drive while cleanup is running.

For an optional standalone executable on Windows:

```bat
.venv\Scripts\python.exe -m pip install pyinstaller
.venv\Scripts\python.exe -m PyInstaller --onefile --windowed --name DriveCleaner app.py
```

The executable is written to `dist\DriveCleaner.exe`. Build on Windows; this repository does not include a prebuilt Windows executable.

Developer checks: `python -m unittest discover -s tests -v`. Windows GUI and Recycle Bin integration require a Windows machine for final verification.
