import queue
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
import app


class SafetyTests(unittest.TestCase):
    def test_scan_preserves_information_and_ignores_links(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in ['setup.EXE', 'tool.jar', 'photo.jpg', 'keys.txt',
                         'accounts.xlsx', 'letter.docx', 'backup.zip', 'unknown', 'movie.mp4']:
                (root / name).write_text('test')
            (root / '$RECYCLE.BIN').mkdir()
            (root / '$RECYCLE.BIN' / 'old.exe').touch()
            (root / 'link.exe').symlink_to(root / 'setup.EXE')
            events = []
            app.scan(root, threading.Event(), events.append)
            self.assertEqual({e[1].name for e in events if e[0] == 'file'},
                             {'setup.EXE', 'tool.jar', 'photo.jpg'})
            self.assertEqual(events[-1], ('done',))

    def test_targets_must_be_files_inside_root_without_links(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            root = base / 'drive'
            root.mkdir()
            target = root / 'setup.exe'
            target.touch()
            app.validate_target(target, root)
            outside = base / 'outside.exe'
            outside.touch()
            with self.assertRaises(ValueError):
                app.validate_target(outside, root)
            with self.assertRaises(ValueError):
                app.validate_target(root, root)
            link = root / 'linked'
            link.symlink_to(base, target_is_directory=True)
            with self.assertRaises(ValueError):
                app.validate_target(link / 'outside.exe', root)

    def test_failed_recycle_keeps_file_and_reports_error(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'keep.exe'
            path.touch()
            class FakeUI:
                busy = False
                root_path = root
                stop = threading.Event()
                events = queue.Queue()
                def set_busy(self, value):
                    self.busy = value
                class status:
                    @staticmethod
                    def set(value):
                        pass
            ui = FakeUI()
            with patch('app.send2trash', side_effect=OSError('recycle unavailable')):
                app.Cleaner.recycle(ui, [path])
                error = ui.events.get(timeout=5)
                done = ui.events.get(timeout=5)
            self.assertEqual(error[0], 'error')
            self.assertEqual(done, ('recycled', 0, 1))
            self.assertTrue(path.exists())


if __name__ == '__main__':
    unittest.main()
