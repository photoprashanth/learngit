@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
    py -3 -m venv .venv
    if errorlevel 1 goto failure
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failure
.venv\Scripts\python.exe app.py
if errorlevel 1 goto failure
exit /b 0
:failure
echo Setup or startup failed. Install Python 3.10 or newer from python.org, including Tcl/Tk and the Python launcher.
pause
exit /b 1
