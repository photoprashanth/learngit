"""Conservative external-drive cleanup. Run with Python 3.10+ on Windows."""
import os
import queue
import stat
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageOps, ImageTk
from send2trash import send2trash

# Unknown formats, archives, scripts and disk images are deliberately preserved.
SOFTWARE = {'.exe', '.jar', '.msi', '.msp', '.msix', '.msixbundle', '.appx',
            '.appxbundle', '.dll', '.sys', '.ocx', '.scr', '.com'}
IMAGES = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tif', '.tiff', '.ico'}
SKIP = {'$recycle.bin', 'system volume information', '.drive-cleaner-quarantine'}


def linked(path):
    info = path.lstat()
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, 'st_file_attributes', 0) & 0x400)


def scan(root, stop, emit):
    """Never follow symbolic links or Windows junctions/reparse points."""
    pending = [root]
    while pending and not stop.is_set():
        folder = pending.pop()
        try:
            with os.scandir(folder) as entries:
                for entry in entries:
                    if stop.is_set():
                        break
                    path = Path(entry.path)
                    try:
                        if linked(path):
                            continue
                        if entry.is_dir(follow_symlinks=False):
                            if entry.name.casefold() not in SKIP:
                                pending.append(path)
                        elif entry.is_file(follow_symlinks=False):
                            suffix = path.suffix.lower()
                            if suffix in SOFTWARE or suffix in IMAGES:
                                emit(('file', path, entry.stat(follow_symlinks=False).st_size,
                                      'software' if suffix in SOFTWARE else 'image'))
                    except OSError as exc:
                        emit(('error', f'{path}: {exc}'))
        except OSError as exc:
            emit(('error', f'{folder}: {exc}'))
    emit(('done',))


def validate_target(path, root):
    """Recheck containment and links immediately before a removal."""
    path = Path(path)
    root = Path(root)
    path.relative_to(root)
    if path == root:
        raise ValueError('Cannot remove the selected root')
    for part in [path, *path.parents]:
        if linked(part):
            raise ValueError('Links and reparse points are never removed')
        if part == root:
            break
    if not path.is_file():
        raise ValueError('Target is no longer a regular file')
    path.resolve().relative_to(root.resolve())


class Cleaner(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Drive Cleaner — preserve your information')
        self.geometry('1100x760')
        self.root_path = None
        self.events = queue.Queue(maxsize=2000)
        self.stop = threading.Event()
        self.busy = False
        self.software = {}
        self.images = []
        self.image_index = 0
        self.preview = None
        self.errors = []
        self.path_text = tk.StringVar()
        self.status = tk.StringVar(value='Choose an external drive or folder to begin.')
        bar = ttk.Frame(self, padding=10)
        bar.pack(fill='x')
        ttk.Entry(bar, textvariable=self.path_text, state='readonly').pack(side='left', fill='x', expand=True)
        self.choose = ttk.Button(bar, text='Choose drive / folder', command=self.pick)
        self.choose.pack(side='left', padx=5)
        self.scan_button = ttk.Button(bar, text='Scan', command=self.start_scan)
        self.scan_button.pack(side='left')
        ttk.Button(bar, text='Stop scan', command=self.stop.set).pack(side='left', padx=5)
        ttk.Label(self, text='Documents, media and unknown formats are kept. Nothing is deleted during a scan.', padding=8).pack(anchor='w')
        tabs = ttk.Notebook(self)
        tabs.pack(fill='both', expand=True, padx=10)
        software_tab = ttk.Frame(tabs)
        image_tab = ttk.Frame(tabs)
        tabs.add(software_tab, text='Software review')
        tabs.add(image_tab, text='Image review')
        ttk.Label(software_tab, text='Select files to recycle (Ctrl/Shift for multiple). Check for software you still need.', padding=8).pack(anchor='w')
        self.tree = ttk.Treeview(software_tab, columns=('path', 'size'), show='headings', selectmode='extended')
        self.tree.heading('path', text='Software file')
        self.tree.heading('size', text='Size (MiB)')
        self.tree.column('path', width=820)
        self.tree.column('size', width=100)
        scroll = ttk.Scrollbar(software_tab, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)
        buttons = ttk.Frame(software_tab, padding=8)
        buttons.pack(fill='x')
        ttk.Button(buttons, text='Select all software', command=lambda: self.tree.selection_set(self.tree.get_children())).pack(side='left')
        self.recycle_button = ttk.Button(buttons, text='Recycle selected software…', command=self.recycle_software)
        self.recycle_button.pack(side='left', padx=10)
        self.image_label = ttk.Label(image_tab, anchor='center')
        self.image_label.pack(fill='both', expand=True)
        self.image_name = ttk.Label(image_tab, wraplength=1000)
        self.image_name.pack(pady=6)
        nav = ttk.Frame(image_tab, padding=10)
        nav.pack()
        ttk.Button(nav, text='Previous', command=lambda: self.advance(-1)).pack(side='left', padx=5)
        ttk.Button(nav, text='Keep / Next', command=lambda: self.advance(1)).pack(side='left', padx=5)
        self.delete_image = ttk.Button(nav, text='Recycle this image', command=self.recycle_image)
        self.delete_image.pack(side='left', padx=15)
        ttk.Label(image_tab, text='One click sends the displayed image to the Recycle Bin. There is no permanent-delete fallback.').pack(pady=5)
        ttk.Label(self, textvariable=self.status, padding=10, wraplength=1050).pack(fill='x')
        ttk.Button(self, text='Show scan / deletion errors', command=self.show_errors).pack(pady=3)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.after(75, self.poll)

    def close(self):
        if self.busy and not messagebox.askyesno('Operation running', 'Close after the current file operation? Remaining queued work will stop.'):
            return
        self.stop.set()
        self.destroy()

    def pick(self):
        if self.busy:
            return
        folder = filedialog.askdirectory(title='Select external drive or folder')
        if folder:
            self.path_text.set(folder)

    def set_busy(self, busy):
        self.busy = busy
        for widget in (self.choose, self.scan_button, self.recycle_button, self.delete_image):
            widget.configure(state='disabled' if busy else 'normal')

    def start_scan(self):
        if self.busy or not self.path_text.get():
            return
        root = Path(self.path_text.get()).absolute()
        try:
            if linked(root) or not root.is_dir():
                raise ValueError('Choose a real directory, not a link or junction.')
            if os.name == 'nt':
                system = Path(os.environ.get('SystemRoot', 'C:/Windows')).anchor.lower()
                if root.anchor.lower() == system:
                    raise ValueError('For safety, select a drive other than the Windows system drive.')
        except (OSError, ValueError) as exc:
            messagebox.showerror('Cannot scan', str(exc))
            return
        self.root_path = root
        self.software.clear()
        self.images.clear()
        self.errors.clear()
        self.tree.delete(*self.tree.get_children())
        self.image_index = 0
        self.show_image()
        self.stop.clear()
        self.set_busy(True)
        self.status.set('Scanning… files are only listed, never deleted.')
        threading.Thread(target=scan, args=(root, self.stop, self.events.put), daemon=True).start()

    def poll(self):
        for _ in range(250):
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break
            if event[0] == 'file':
                _, path, size, kind = event
                if kind == 'software':
                    key = self.tree.insert('', 'end', values=(str(path), f'{size / 1048576:.2f}'))
                    self.software[key] = path
                else:
                    self.images.append(path)
            elif event[0] == 'error':
                self.errors.append(event[1])
            elif event[0] == 'done':
                self.set_busy(False)
                self.status.set(f'Scan {"stopped" if self.stop.is_set() else "complete"}: {len(self.software)} software files, {len(self.images)} images, {len(self.errors)} errors. Review before recycling.')
                self.show_image()
            elif event[0] == 'removed':
                path = event[1]
                for key, value in list(self.software.items()):
                    if value == path:
                        self.tree.delete(key)
                        del self.software[key]
                if path in self.images:
                    self.images.remove(path)
            elif event[0] == 'recycled':
                self.set_busy(False)
                self.status.set(f'Recycled {event[1]} file(s); {event[2]} failed. Restore files using Windows Recycle Bin. See errors for failures.')
                self.show_image()
        self.after(75, self.poll)

    def recycle(self, paths):
        if self.busy or not paths:
            return
        self.set_busy(True)
        self.stop.clear()
        root = self.root_path
        def work():
            success = failures = 0
            for path in paths:
                if self.stop.is_set():
                    break
                try:
                    validate_target(path, root)
                    send2trash(str(path))
                    success += 1
                    self.events.put(('removed', path))
                except Exception as exc:
                    failures += 1
                    self.events.put(('error', f'{path}: {exc}'))
            self.events.put(('recycled', success, failures))
        self.status.set('Moving files to Recycle Bin…')
        threading.Thread(target=work, daemon=True).start()

    def recycle_software(self):
        paths = [self.software[key] for key in self.tree.selection() if key in self.software]
        if paths and messagebox.askyesno('Recycle selected software?', f'Move {len(paths)} selected software files to Recycle Bin?\n\nSoftware may stop working. Keep installers you still need. No permanent deletion will be attempted.'):
            self.recycle(paths)

    def advance(self, step):
        if self.images and not self.busy:
            self.image_index = (self.image_index + step) % len(self.images)
            self.show_image()

    def show_image(self):
        self.preview = None
        self.image_label.configure(image='', text='No images to review.')
        self.image_name.configure(text='')
        if not self.images:
            return
        self.image_index %= len(self.images)
        path = self.images[self.image_index]
        self.image_name.configure(text=f'{self.image_index + 1} / {len(self.images)} — {path}')
        try:
            with Image.open(path) as original:
                original.thumbnail((950, 450))
                picture = ImageOps.exif_transpose(original)
                self.preview = ImageTk.PhotoImage(picture.copy())
            self.image_label.configure(image=self.preview, text='')
        except Exception as exc:
            self.image_label.configure(text=f'Preview unavailable: {exc}')

    def recycle_image(self):
        if self.images and not self.busy:
            self.recycle([self.images[self.image_index]])

    def show_errors(self):
        window = tk.Toplevel(self)
        window.title('Errors — affected files were kept')
        text = tk.Text(window, width=110, height=25, wrap='word')
        text.pack(fill='both', expand=True)
        text.insert('1.0', '\n'.join(self.errors) or 'No errors.')
        text.configure(state='disabled')


if __name__ == '__main__':
    Cleaner().mainloop()
